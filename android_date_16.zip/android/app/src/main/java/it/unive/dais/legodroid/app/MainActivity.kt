package it.unive.dais.legodroid.app

import android.widget.Spinner
import android.widget.TextView
import it.unive.dais.legodroid.lib.plugs.TachoMotor
import it.unive.dais.legodroid.lib.GenEV3
import it.unive.dais.legodroid.lib.EV3
import android.os.Bundle
import android.util.Log
import android.view.View

import it.unive.dais.legodroid.lib.comm.BluetoothConnection
import it.unive.dais.legodroid.lib.util.Prelude
import kotlin.Throws
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.AdapterView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import it.unive.dais.legodroid.app.MainActivity.MyCustomApi
import it.unive.dais.legodroid.lib.comm.Connection
import java.io.IOException
import java.util.concurrent.ExecutionException

class MainActivity : AppCompatActivity() {
    var ev3_action: Spinner? = null
    var tv: TextView? = null
    var str: String? = null
    var motor_A: TachoMotor? = null
    var motor_B: TachoMotor? = null
    var motor_C: TachoMotor? = null

    // example of custom API
    class MyCustomApi private constructor(ev3: GenEV3<out EV3.Api>) : EV3.Api(ev3) {
        fun mySpecialCommand() { /* do something special */
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        try {
            // connect to EV3 via bluetooth
            val c: Connection<*> = BluetoothConnection("EV3")
            val ev3 = EV3(c.connect()) // replace with your own brick name
            val stopButton = findViewById<Button>(R.id.stopButton)
            stopButton.setOnClickListener { v: View? ->
                ev3.cancel() // fire cancellation signal to the EV3 task
            }
            val startButton = findViewById<Button>(R.id.startButton)
            startButton.setOnClickListener { v: View? ->
                Prelude.trap {
                    ev3.run { api: EV3.Api ->
                        legoMain(
                            api
                        )
                    }
                }
            }
        } finally {

        }
    }

    // main program executed by EV3
    @Throws(IOException::class)
    fun legoMain(api: EV3.Api) {

        motor_A = api.getTachoMotor(EV3.OutputPort.A)
        motor_B = api.getTachoMotor(EV3.OutputPort.B)
        motor_C = api.getTachoMotor(EV3.OutputPort.C)
        ev3_action = findViewById<View>(R.id.sp) as Spinner
        tv = findViewById<View>(R.id.tv) as TextView
        str = ev3_action!!.selectedItem as String
        ev3_action!!.onItemSelectedListener = object : OnItemSelectedListener {
            //下拉式選單傾聽器
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View, i: Int, l: Long) {
                str = ev3_action!!.selectedItem as String
                tv!!.text = str
                when (str) {
                    "前進" -> {
                        //command to move
                        motor_A!!.setStepSpeed(100, 0, 500, 0, true)
                        motor_B!!.setStepSpeed(100, 0, 500, 0, true)
                    }
                    "後退" -> {
                        //command to move
                            motor_A!!.setStepSpeed(-100, 0, 500, 0, true)
                            motor_B!!.setStepSpeed(-100, 0, 500, 0, true)
                    }
                    "左轉" -> {
                        //command to move
                            motor_C!!.setStepSpeed(-100, 0, 200, 0, true)
                            motor_A!!.setStepSpeed(100, 0, 300, 0, true)
                            motor_B!!.setStepSpeed(100, 0, 300, 0, true)
                    }
                    "右轉" -> {
                        //command to move
                            motor_C!!.setStepSpeed(100, 0, 200, 0, true)
                            motor_A!!.setStepSpeed(100, 0, 300, 0, true)
                            motor_B!!.setStepSpeed(100, 0, 300, 0, true)

                    }
                    "停下來" -> {
                        //command to move
                        //不確定
                            motor_C!!.setStepSpeed(0, 0, 0, 0, true)
                            motor_A!!.setStepSpeed(0, 0, 0, 0, true)
                            motor_B!!.setStepSpeed(0, 0, 0, 0, true)

                    }
                }
            }

            override fun onNothingSelected(adapterView: AdapterView<*>?) {}
        }
    }

//    //前進
//    @Throws(IOException::class)
//    fun a(api: EV3.Api) {
//        motor_A = api.getTachoMotor(EV3.OutputPort.A)
//        motor_B = api.getTachoMotor(EV3.OutputPort.B)
//        try {
//            motor_A!!.setStepSpeed(100, 0, 500, 0, true)
//            motor_B!!.setStepSpeed(100, 0, 500, 0, true)
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    //後退
//    @Throws(IOException::class)
//    fun b(api: EV3.Api) {
//        motor_A = api.getTachoMotor(EV3.OutputPort.A)
//        motor_B = api.getTachoMotor(EV3.OutputPort.B)
//        try {
//            motor_A!!.setStepSpeed(-100, 0, 500, 0, true)
//            motor_B!!.setStepSpeed(-100, 0, 500, 0, true)
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    //左轉
//    @Throws(IOException::class)
//    fun c(api: EV3.Api) {
//        motor_A = api.getTachoMotor(EV3.OutputPort.A)
//        motor_B = api.getTachoMotor(EV3.OutputPort.B)
//        motor_C = api.getTachoMotor(EV3.OutputPort.C)
//        try {
//            motor_C!!.setStepSpeed(-100, 0, 200, 0, true)
//            motor_A!!.setStepSpeed(100, 0, 300, 0, true)
//            motor_B!!.setStepSpeed(100, 0, 300, 0, true)
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    //右轉
//    @Throws(IOException::class)
//    fun d(api: EV3.Api) {
//        motor_A = api.getTachoMotor(EV3.OutputPort.A)
//        motor_B = api.getTachoMotor(EV3.OutputPort.B)
//        motor_C = api.getTachoMotor(EV3.OutputPort.C)
//        try {
//            motor_C!!.setStepSpeed(100, 0, 200, 0, true)
//            motor_A!!.setStepSpeed(100, 0, 300, 0, true)
//            motor_B!!.setStepSpeed(100, 0, 300, 0, true)
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    //停下來
//    @Throws(IOException::class)
//    fun e(api: EV3.Api) {
//        motor_A = api.getTachoMotor(EV3.OutputPort.A)
//        motor_B = api.getTachoMotor(EV3.OutputPort.B)
//        motor_C = api.getTachoMotor(EV3.OutputPort.C)
//        try {
//            motor_C!!.setStepSpeed(0, 0, 0, 0, true)
//            motor_A!!.setStepSpeed(0, 0, 0, 0, true)
//            motor_B!!.setStepSpeed(0, 0, 0, 0, true)
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
}