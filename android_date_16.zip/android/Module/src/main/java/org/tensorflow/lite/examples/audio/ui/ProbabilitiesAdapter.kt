/*
 * Copyright 2022 The TensorFlow Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *             http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.tensorflow.lite.examples.audio.ui

import android.content.res.ColorStateList


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import it.unive.dais.legodroid.lib.EV3

import it.unive.dais.legodroid.lib.plugs.TachoMotor



import org.tensorflow.lite.examples.audio.R

import org.tensorflow.lite.examples.audio.databinding.ItemProbabilityBinding
import org.tensorflow.lite.support.label.Category
import java.io.IOException


internal class ProbabilitiesAdapter : RecyclerView.Adapter<ProbabilitiesAdapter.ViewHolder>() {
    var categoryList: List<Category> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemProbabilityBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categoryList[position]
        holder.bind(category.label, category.score, category.index)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    open class ViewHolder(private val binding: ItemProbabilityBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private var primaryProgressColorList: IntArray
        private var backgroundProgressColorList: IntArray

        init {
            primaryProgressColorList =
                binding.root.resources.getIntArray((R.array.colors_progress_primary))
            backgroundProgressColorList =
                binding.root.resources.getIntArray((R.array.colors_progress_background))
        }

        open fun bind(label: String, score: Float, index: Int){
            with(binding) {
                var motor_A: TachoMotor? = null
                var motor_B: TachoMotor? = null
                var motor_C: TachoMotor? = null
                labelTextView.text = label

                @Throws(IOException::class)
                fun legoMain(api: EV3.Api) {
                    motor_A = api.getTachoMotor(EV3.OutputPort.A)
                    motor_B = api.getTachoMotor(EV3.OutputPort.B)
                    //方向的motor
                    motor_C = api.getTachoMotor(EV3.OutputPort.C)
                }
                //以下藍芽連接
//                val c: Connection<*> = BluetoothConnection("EV3")
//                val ev3 = EV3(c.connect()) // replace with your own brick name
//                Prelude.trap {
//                    ev3.run { api: EV3.Api ->
//                        legoMain(
//                            api
//                        )
//                    }
//                }

                //抓取模型label字串做相對應的動作
//                when(label){
//                    "0 停下來"->{
//                        motor_A!!.setStepSpeed(0, 0, 500, 0, true)
//                        motor_B!!.setStepSpeed(0, 0, 500, 0, true)
//                    }
//                    "1 前進"->{
//                        motor_A!!.setStepSpeed(100, 0, 500, 0, true)
//                        motor_B!!.setStepSpeed(100, 0, 500, 0, true)
//                    }
//                    "2 右轉"->{
//                        motor_C!!.setStepSpeed(100, 0, 200, 0, true)
//                        motor_A!!.setStepSpeed(100, 0, 300, 0, true)
//                        motor_B!!.setStepSpeed(100, 0, 300, 0, true)
//                    }
//                    "3 左轉"->{
//                        motor_C!!.setStepSpeed(-100, 0, 200, 0, true)
//                        motor_A!!.setStepSpeed(100, 0, 300, 0, true)
//                        motor_B!!.setStepSpeed(100, 0, 300, 0, true)
//                    }
//                    "4 後退"->{
//                        motor_A!!.setStepSpeed(-100, 0, 500, 0, true)
//                        motor_B!!.setStepSpeed(-100, 0, 500, 0, true)
//                    }
//
//                }

                progressBar.progressBackgroundTintList =
                    ColorStateList.valueOf(
                        backgroundProgressColorList[index % backgroundProgressColorList.size]
                    )

                progressBar.progressTintList =
                    ColorStateList.valueOf(
                        primaryProgressColorList[index % primaryProgressColorList.size]
                    )

                val newValue = (score * 100).toInt()
                progressBar.progress = newValue



            }

        }
    }
}