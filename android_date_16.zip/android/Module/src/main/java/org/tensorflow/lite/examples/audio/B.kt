package org.tensorflow.lite.examples.audio


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button


class B : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<View>(R.id.btn) as Button

        btn.setOnClickListener {
            finish() //按button會結束app程式

        }
    }

    fun btnMainClick(view: View) {
        finish()   //按button會結束app程式
    }

}